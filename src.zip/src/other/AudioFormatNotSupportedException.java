package other;

public class AudioFormatNotSupportedException extends Exception{
	
	public AudioFormatNotSupportedException(){
		super("Audio Format is not Supported");
	}

}
